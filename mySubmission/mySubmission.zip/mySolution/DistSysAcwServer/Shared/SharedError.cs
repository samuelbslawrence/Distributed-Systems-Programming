﻿namespace DistSysAcwServer.Shared
{
    #region Untouched Skeleton Solution
    public class SharedError
    {
        public string? Message { get; set; }
        public int? StatusCode { get; set; }
    }
    #endregion
}