﻿using DistSysAcwServer.Controllers;
using DistSysAcwServer.Models;
using DistSysAcwServer.Repositories;
using DistSysAcwServer.Shared;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DistSysAcwServer.Controllers
{
    #region Task 4
    public class UserController : BaseController
    {
        private readonly UserRepository _userRepository;

        public UserController(
            UserContext dbcontext,
            SharedError error,
            UserRepository userRepository) : base(dbcontext, error)
        {
            _userRepository = userRepository;
        }

        [HttpGet("api/user/new")]
        public async Task<IActionResult> CheckUserExists([FromQuery] string? username)
        {
            // If no username is provided
            if (string.IsNullOrWhiteSpace(username))
            {
                return Ok("False - User Does Not Exist! Did you mean to do a POST to create a new user?");
            }

            // Check if user exists by username
            bool userExists = await DbContext.Users.AnyAsync(u => u.UserName == username);

            if (userExists)
            {
                return Ok("True - User Does Exist! Did you mean to do a POST to create a new user?");
            }
            else
            {
                return Ok("False - User Does Not Exist! Did you mean to do a POST to create a new user?");
            }
        }

        [HttpPost("api/user/new")]
        public async Task<IActionResult> CreateUser([FromBody] string? username)
        {
            // Check if username is provided
            if (string.IsNullOrWhiteSpace(username))
            {
                return BadRequest("Oops. Make sure your body contains a string with your username and your Content-Type is Content-Type:application/json");
            }

            // Check if username is already taken
            bool userExists = await DbContext.Users.AnyAsync(u => u.UserName == username);
            if (userExists)
            {
                return StatusCode(403, "Oops. This username is already in use. Please try again with a new username.");
            }

            // Determine if this is the first user (should be admin)
            bool isFirstUser = !await DbContext.Users.AnyAsync();
            string role = isFirstUser ? "Admin" : "User";

            // Create new user
            var newUser = new User
            {
                ApiKey = Guid.NewGuid().ToString(),
                UserName = username,
                Role = role
            };

            // Add user to database
            DbContext.Users.Add(newUser);
            await DbContext.SaveChangesAsync();

            // Return API Key
            return Ok(newUser.ApiKey);
        }
    }
    #endregion
}