﻿namespace DistSysAcwServer.Shared
{
    public class SharedError
    {
        public string? Message { get; set; }
        public int? StatusCode { get; set; }
    }
}